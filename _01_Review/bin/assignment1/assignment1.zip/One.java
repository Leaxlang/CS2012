package assignment1;

public class One {
	public static void main(String[] args) {
		//Hello World! 
        System.out.println("Hello World!");
	}

}
