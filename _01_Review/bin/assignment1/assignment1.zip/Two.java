package assignment1;
import java.util.*;

public class Two{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        //String input
        System.out.println("Please input a String:");
        String StringInput = input.next();
        System.out.println(StringInput);

        //Integer input
        System.out.println("Please input a Integer:");
        int IntInput = input.nextInt();
        System.out.println(IntInput);

        input.nextLine();  // Consume newline left-over 
        
        //Anything input
        System.out.println("Please input anything:");
        String LastInput = input.nextLine();
        System.out.println(LastInput);
        
        input.close();
    }
	
}
